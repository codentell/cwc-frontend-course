import React from "react";
import Signup from "./pages/Signup";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Signup />
    </div>
  );
}

export default App;
