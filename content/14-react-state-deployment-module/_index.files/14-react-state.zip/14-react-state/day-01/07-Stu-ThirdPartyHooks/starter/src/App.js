import React from "react";
import Survey from "./pages/Survey";
import "./App.css";

function App() {
  return (
      <div>
          <Survey />
      </div>
  );
}

export default App;
