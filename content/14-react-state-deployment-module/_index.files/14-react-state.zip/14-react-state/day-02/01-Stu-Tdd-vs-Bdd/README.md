# Partner Do: Group Discussion on TDD vs. BDD

In this activity, you will discuss the differences between TDD and BDD as well as decide on which you think is better.

## Instructions
1. Among your group members, discuss the following points:
   * What is TDD?
   * What is BDD?
   * How are TDD and BDD similar?
   * How are TDD and BDD different?
   * Which do you feel is better and why?

---

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
