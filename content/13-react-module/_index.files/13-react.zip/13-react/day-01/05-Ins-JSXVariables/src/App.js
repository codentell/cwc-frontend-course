import React from "react";
import JSXVariables from "./components/JSXVariables";

function App() {
  return <JSXVariables />;
}

export default App;
