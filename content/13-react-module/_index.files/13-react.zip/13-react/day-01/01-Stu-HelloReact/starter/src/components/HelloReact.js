import React from "react";

function HelloReact() {
  return <p>Hello World!</p>;
}

export default HelloReact;
