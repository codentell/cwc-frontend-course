import React from "react";
import HelloReact from "./components/HelloReact";

function App() {
  return <HelloReact />;
}

export default App;
