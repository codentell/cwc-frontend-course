import React from "react";
import HelloBootstrap from "./components/HelloBootstrap";

function App() {
  return <HelloBootstrap />;
}

export default App;
