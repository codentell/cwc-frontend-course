import React from "react";
import OmdbContainer from "./components/OmdbContainer";

function App() {
  return <OmdbContainer />;
}

export default App;
