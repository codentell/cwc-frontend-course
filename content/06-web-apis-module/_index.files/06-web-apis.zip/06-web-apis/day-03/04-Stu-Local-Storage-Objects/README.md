# Local Storage with Objects

One of the most important skills a developer can learn is how to quickly research and find solutions to problems. Our application is attempting to store an object and not the data in it. Why?

## Instructions

* Find and implement a solution that allows the application to store and retrieve objects to and from `localStorage`.


**Hint:** You need to convert the object to a string, and vice versa.

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
