// Various Arrays
var brands = ["Acer", "Apple", "Sony", "Samsung"];
var heroes = ["Black Panther", "Cyborg", "Black Canary", "Donna Troy", "Huntress", "Blue Beetle", "Captain Atom"];
var booksOnMyShelf = ["Calculus Early Transcendentals", "Ravens", "The Self Illusion", "Harry Potter"];
var thingsInFrontOfMe = ["Laptop", "Beanbag", "Cats", "Slippers"];
var howIFeel = ["Sleep Deprived", "Wired on Coffee", "Excited"];

// FUNCTIONS
// ========================================================================================

// Here we create a "Function" that allows us to "call" (run) the loop for any array we wish.
// We pass in an array as an "argument".
function consoleInside(arr) {

  // We then loop through the selected array.
  for (var i = 0; i < arr.length; i++) {

    // Each time we print the value inside the array.
    console.log(arr[i]);
  }
  console.log("---------");
}


// FUNCTION CALLS (Execution)
// =======================================================================================

// Here we call the function to run our for-loop code on each of the following arrays.
consoleInside(brands);
consoleInside(heroes);
consoleInside(booksOnMyShelf);
consoleInside(thingsInFrontOfMe);
consoleInside(howIFeel);
