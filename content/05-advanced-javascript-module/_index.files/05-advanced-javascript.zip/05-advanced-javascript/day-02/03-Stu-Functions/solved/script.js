function addOneAndTwo() {
  console.log(1+2);
  return
}

var subtractTwentyAndTen = function() {
  console.log(20-10);
  return
}

var side = 54;

function areaOfASquare() {
  var area = side * side;
  console.log('area: ', area)
  return
}

addOneAndTwo();
subtractTwentyAndTen();
areaOfASquare();
