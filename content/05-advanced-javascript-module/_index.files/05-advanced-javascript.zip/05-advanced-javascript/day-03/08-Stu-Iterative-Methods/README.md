# 📐 Add Comments to Implementation of Functional Loops

Work with a partner to add comments describing the functionality of the code found in [script.js](./starter/script.js).

## 📝 Notes

Refer to the documentation:

* [map()](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map)

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
