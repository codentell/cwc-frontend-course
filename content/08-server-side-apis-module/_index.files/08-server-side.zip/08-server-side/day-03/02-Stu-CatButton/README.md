# Cat Button

## Instructions

* Open the file `cat-button.html` in your browser. Then take a few moments to see what the application does.

* Fill in the missing comments for each line to describe what each section does.

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
