# New York Times Article Search - Phase 04

## All Together

* Deploy your app to GitHub Pages!

* Then slack your links to your instructors and TAs.

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
