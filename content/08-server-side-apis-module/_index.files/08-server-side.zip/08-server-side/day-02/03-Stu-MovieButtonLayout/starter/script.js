 // Initial array of movies
 var movies = ["The Matrix", "Dune", "Mr. Right", "The Lion King"];

 // Function for displaying movie data
 function renderButtons() {

   // YOUR CODE GOES HERE

 }

 // This function handles events where one button is clicked
 $("#add-movie").on("click", function() {

   // YOUR CODE GOES HERE

 });

 // Calling the renderButtons function to display the initial list of movies
 renderButtons();