# Click JSON Printing

## Instructions

* Using your previous activity files or the starter code provided complete the following:
 
  * Create a function called `displayMovieInfo` that when called prints JSON data for the appropriate movie.

    * This function should be called when a Movie button is clicked.

## 💡 Hint 

Make sure you utilize data-attributes.

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
