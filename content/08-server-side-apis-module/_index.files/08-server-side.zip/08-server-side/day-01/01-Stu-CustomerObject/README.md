# Customer Object

## Instructions

* Using the instructions shown in the comments, create `console.log` statements that parse out the requested information.

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
