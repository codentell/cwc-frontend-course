const Game = require("./lib/Game");

// Initialize a new Game object
const game = new Game();

// Start playing
game.play();
