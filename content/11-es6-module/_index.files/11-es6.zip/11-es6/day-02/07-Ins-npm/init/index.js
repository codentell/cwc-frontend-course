const badmath = require('badmath');

console.log(badmath.pie);

console.log(badmath.predictable());
