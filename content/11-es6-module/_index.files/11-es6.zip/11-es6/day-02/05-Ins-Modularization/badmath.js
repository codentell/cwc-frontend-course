const pie = 'apple';

const predictable = () => 1;

// module.exports is an object we use to store variables or methods
module.exports = {
  pie,
  predictable,
};
