
alert("We definitely rock!");

// Notice that the confirm and prompt take in variables but the alert doesn't
var doYouRock = confirm("The question is, do *you* rock?");
var howMuchRock = prompt("How much do you rock?");

// Alert the results
alert(doYouRock);
alert(howMuchRock);