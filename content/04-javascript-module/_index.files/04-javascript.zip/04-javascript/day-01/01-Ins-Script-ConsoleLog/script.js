// External files make your code organized and easier to maintain
console.log("This is the log for the 🔥EXTERNAL🔥JavaScript");
